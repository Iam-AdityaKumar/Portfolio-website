import React from 'react';
import { motion } from 'framer-motion';
import { Github, Linkedin, Mail, ExternalLink } from 'lucide-react';
import { ThemeToggle } from './components/ThemeToggle';
import { SkillBar } from './components/SkillBar';
import { skills } from './data/skills';

function App() {
  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-gray-100 transition-colors duration-200">
      <ThemeToggle />
      
      {/* Hero Section */}
      <header className="container mx-auto px-4 py-20">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="max-w-3xl mx-auto text-center"
        >
          <h1 className="text-5xl font-bold mb-6">Aditya Kumar</h1>
          <p className="text-xl text-gray-600 dark:text-gray-400 mb-8">
            Electronics & Communication Engineering Student at MMMUT, Gorakhpur
          </p>
          <div className="flex justify-center gap-4">
            <a href="https://github.com/Iam-AdityaKumar" className="text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-gray-100">
              <Github className="w-6 h-6" />
            </a>
            <a href="https://www.linkedin.com/in/iam-aditya-kumar/" className="text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-gray-100">
              <Linkedin className="w-6 h-6" />
            </a>
            <a href="mailto:aditya@example.com" className="text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-gray-100">
              <Mail className="w-6 h-6" />
            </a>
          </div>
        </motion.div>
      </header>

      {/* About Section */}
      <section className="bg-white dark:bg-gray-800 py-20">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ duration: 0.5 }}
            className="max-w-3xl mx-auto"
          >
            <h2 className="text-3xl font-bold mb-8">About Me</h2>
            <p className="text-gray-600 dark:text-gray-400 leading-relaxed mb-6">
              I'm a passionate Electronics & Communication Engineering student at Madan Mohan Malaviya University of Technology, Gorakhpur. 
              I specialize in full-stack development and have a strong foundation in data structures and algorithms.
            </p>
            <p className="text-gray-600 dark:text-gray-400 leading-relaxed">
              Currently exploring advanced concepts in system design and cloud computing while working on innovative projects 
              that solve real-world problems.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Skills Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold mb-12 text-center">Skills</h2>
          <div className="max-w-3xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-8">
            {Object.entries(
              skills.reduce((acc, skill) => ({
                ...acc,
                [skill.category]: [...(acc[skill.category] || []), skill],
              }), {} as Record<string, typeof skills>)
            ).map(([category, categorySkills]) => (
              <motion.div
                key={category}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="space-y-4"
              >
                <h3 className="text-xl font-semibold capitalize mb-4">{category}</h3>
                {categorySkills.map((skill) => (
                  <SkillBar key={skill.name} skill={skill} />
                ))}
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-white dark:bg-gray-800 py-8">
        <div className="container mx-auto px-4 text-center text-gray-600 dark:text-gray-400">
          <p>© 2024 Aditya Kumar. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}

export default App;