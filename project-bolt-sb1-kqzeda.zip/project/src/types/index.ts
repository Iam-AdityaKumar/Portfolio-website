export interface Skill {
  name: string;
  level: number;
  category: 'programming' | 'web' | 'database' | 'tools';
}

export interface Project {
  title: string;
  description: string;
  technologies: string[];
  image: string;
  link?: string;
}