import { Skill } from '../types';

export const skills: Skill[] = [
  { name: 'C/C++', level: 90, category: 'programming' },
  { name: 'Python', level: 85, category: 'programming' },
  { name: 'Java', level: 80, category: 'programming' },
  { name: 'HTML/CSS', level: 95, category: 'web' },
  { name: 'JavaScript', level: 90, category: 'web' },
  { name: 'React.js', level: 85, category: 'web' },
  { name: 'Node.js', level: 85, category: 'web' },
  { name: 'Express.js', level: 80, category: 'web' },
  { name: 'MongoDB', level: 85, category: 'database' },
  { name: 'SQL', level: 85, category: 'database' },
  { name: 'Git', level: 90, category: 'tools' },
  { name: 'Docker', level: 75, category: 'tools' },
  { name: 'Data Structures', level: 90, category: 'programming' },
  { name: 'Algorithms', level: 90, category: 'programming' },
  { name: 'System Design', level: 80, category: 'programming' },
];